Hello

1.The script "index.js" executable in terminal with the command - node index.js
It will create an xlsx file called "DataExport.xlsx" filled with the table data required to be scraped.
No errors where noticed when scraping.

2.The documentation of the db.js file has been done and updated in the file.

3.I was told there will be a third task, none was sent. This is why I am sending 2 comleted tasks.
